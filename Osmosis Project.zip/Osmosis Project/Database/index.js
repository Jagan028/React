// const express = require("express");
// //Create Express App for Request-Response Cycle & to create the Express Server
// const app = express();
// //Create Express Server Port
// const port = 7000;
//  const db=require('./config/mongoose')
// // const Excel = require('exceljs');

// // const path = require('path');


// // const passport=require('./config/passportLocalStrategy')
// // const session=require('express-session')
// // const MongoDBStore = require('connect-mongodb-session')(session)//used monogostore



// // // // const expressLayouts = require('express-ejs-layouts');
// // const cookieParser = require('cookie-parser')

// // // // app.use(express.json());
// // app.use(express.urlencoded());
// // app.use(cookieParser())

// // // // app.use(expressLayouts);
// // // // app.use(express.static('./assets'))

// app.set('view engine','ejs')
// app.set('views','./views')
 
// // const store = new MongoDBStore({
// //   uri: 'mongodb://127.0.0.1/placementfinal', // Update with your MongoDB connection URI
// //   collection: 'sessions'
// // });

// // // Catch errors in the MongoDBStore
// // store.on('error', function (error) {
// //   console.log(error);
// // });
// // app.use(session({
// //   // name:'codeial',
// //   secret:'blah',
// //   saveUninitialized:false,
// //   resave:false,
// //   cookie:{
// //       maxAge:(1000*60*1000)
// //   },
// //    store: store
// // })
// // );
  

// // app.use(passport.initialize())// telling to app use passport
// // app.use(passport.session())
// // app.use(passport.setAuthenticationuser)


// // app.use('/',require('./routes'))
// app.listen(port, (err) => {
// 	if (err) return console.log("Error: ", err);
// 	console.log(`Server is running successfully on port ${port}`);
//     })









const express = require('express');
const mongoose = require('mongoose');
const categoryController = require('./controllers/categoryController');
const Category = require('./models/categoryModel');
const Asset = require('./models/assetModel');

const app = express();
const port = 7001;
app.set('view engine','ejs')
app.set('views','./views')

mongoose.connect('mongodb://127.0.0.1/database1', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(async () => {
  console.log('Connected to MongoDB');
  // Call the function to create the sample data
  const createSampleData = async () => {
  try {
    const frontEnd= await Category.create({ name: 'frontEnd' });
    const backEnd = await Category.create({ name: 'backEnd' });
    const trandingLanguages= await Category.create({ name:'trandingLanguages' });

    await Asset.create({ name: 'HTML', category: frontEnd._id });
    await Asset.create({ name: 'REACT', category: frontEnd._id });
    await Asset.create({ name: 'CSS', category: frontEnd._id });
    await Asset.create({ name: 'JAVASCRIPT', category: frontEnd._id });


    await Asset.create({ name: 'NODEJS', category: backEnd ._id });
    await Asset.create({ name: 'EXPRESS', category: backEnd ._id });

    await Asset.create({ name: 'JAVA', category: trandingLanguages._id });
    await Asset.create({ name: 'PYTHON', category:  trandingLanguages._id });
    await Asset.create({ name: 'C++', category:  trandingLanguages._id });

 
  } catch (error) {
    console.error('Error creating sample data:', error);
  }
};

  await createSampleData();
  console.log('Sample data created.');

app.use(express.static(__dirname));
app.use(express.json());


app.get('/api/categories', categoryController.getCategoriesWithAssets);

  // Start the server after creating the sample data
  app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
  });
}).catch(err => {
  console.error('Error connecting to MongoDB:', err);
});

// Rest of the code remains the same
// ... (controllers, routes, and static files)









