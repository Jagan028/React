const Category = require('../models/categoryModel');
const Asset = require('../models/assetModel');

const getCategoriesWithAssets = async (req, res) => {
  try {
    const categories = await Category.find().lean().exec();
    const result = [];
    for (const category of categories) {
      const assets = await Asset.find({ category: category._id }).lean().exec();
      result.push({ ...category, assets });
    }
      return res.json(result);  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch categories and assets' });
  }
};

module.exports = { getCategoriesWithAssets };
