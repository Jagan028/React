import React from 'react';
import '../css/Footer.css';
import { Button } from './Button';
import { Link } from 'react-router-dom';

function Footer() {
  return (
    <div className='footer-container'>
    
      <div class='footer-links'>
        <div className='footer-link-wrapper d-flex p-3 bg-secondary text-white'>

          <div class='footer-link-1'>
            <h2 className='row p-2'>About Us </h2>
         
          </div>
          <div class='footer-link-items'>
            <h2>Privacy Policy</h2>
       
          </div>
          <div class='footer-link-items'>
            <h2>OSMOSIS</h2>
       
          </div>
          <div class='footer-link-items-a'>
            <h2>We Love to hear from you</h2>
       
          </div>

        </div>
   
      </div>
     
    </div>
  );
}

export default Footer;